// PAQUETE INTERFACES //
package interfaces;

import java.util.ArrayList;

// ══════════════════════════════════════════════════════════════
//  INTERFAZ  ·  IRepositorio<T>
// ══════════════════════════════════════════════════════════════
//  Contrato CRUD genérico: cualquier clase del proyecto se puede guardar, buscar, editar y borrar con estas mismas operaciones.
//  * GENERICIDAD *
//    - El parámetro <T> permite reutilizar el contrato para Institucion, MiembroOrganizacion, Comite, etc.
//  * INTERFAZ *
//    - Define QUÉ se puede hacer, no CÓMO; cada formato (TXT, JSON) lo implementa a su manera
// ══════════════════════════════════════════════════════════════
public interface IRepositorio<T> {

    // ══════════════════════════════════════════════════════════════
    //  LECTURA
    // ══════════════════════════════════════════════════════════════
    // getDataList()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    ArrayList<T> getDataList();
    // buscarPorClave()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    T buscarPorClave(String clave);

    // ══════════════════════════════════════════════════════════════
    //  ESCRITURA
    // ══════════════════════════════════════════════════════════════
    // insertData()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    boolean insertData(T entity);
    // updateData()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    boolean updateData(T oldEntity, T newEntity);
    // deleteData()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    boolean deleteData(T entity);
}
