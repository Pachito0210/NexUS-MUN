// PAQUETE REPOSITORIES //
package repositories;

import interfaces.IRepositorio;
import persistence.GestorArchivoJson;

import java.util.ArrayList;
import java.util.List;

// ══════════════════════════════════════════════════════════════
//  CLASE  ·  BaseRepositorioJson<T>
// ══════════════════════════════════════════════════════════════
//  Repositorio genérico para archivos JSON. Implementa todo el CRUD; cada subclase solo dice cuál es la clave de su objeto.
//  * ABSTRACCIÓN *
//    - Es abstracta: no se instancia, solo es la plantilla de los repositorios JSON
//  * HERENCIA *
//    - Cada repositorio concreto hereda el CRUD completo y solo define getClave
//  * GENERICIDAD *
//    - El parámetro <T> la hace reutilizable para cualquier modelo
//  * COMPOSICIÓN *
//    - Tiene un GestorArchivoJson y le delega la lectura y escritura del archivo
// ══════════════════════════════════════════════════════════════
public abstract class BaseRepositorioJson<T> implements IRepositorio<T> {

    // ─────────────────── ATRIBUTOS ───────────────────
    protected GestorArchivoJson<T> gestor;
    // ───────────────── CONSTRUCTORES ─────────────────
    public BaseRepositorioJson(String nombreArchivo, Class<T> clase) {
        this.gestor = new GestorArchivoJson<>(nombreArchivo, clase);
    }
    public BaseRepositorioJson(GestorArchivoJson<T> gestor) {
        this.gestor = gestor;
    }

    // ══════════════════════════════════════════════════════════════
    //  MÉTODO QUE DEFINE CADA SUBCLASE
    // ══════════════════════════════════════════════════════════════
    // getClave()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    protected abstract String getClave(T entity);

    // ══════════════════════════════════════════════════════════════
    //  LECTURA
    // ══════════════════════════════════════════════════════════════
    // getDataList()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public ArrayList<T> getDataList() {
        return gestor.leerTodo();
    }
    // buscarPorClave()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public T buscarPorClave(String clave) {
        for (T entidad : getDataList()) {
            if (getClave(entidad).equalsIgnoreCase(clave)) {
                return entidad;
            }
        }
        return null;
    }

    // ══════════════════════════════════════════════════════════════
    //  ESCRITURA
    // ══════════════════════════════════════════════════════════════
    // insertData()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public boolean insertData(T entity) {
        if (entity == null || buscarPorClave(getClave(entity)) != null) {
            return false;
        }
        ArrayList<T> lista = getDataList();
        lista.add(entity);
        return gestor.escribirTodo(lista);
    }
    // updateData()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public boolean updateData(T oldEntity, T newEntity) {
        if (oldEntity == null || newEntity == null) {
            return false;
        }
        ArrayList<T> lista = getDataList();
        int posicion = posicionDe(lista, getClave(oldEntity));
        if (posicion == -1) {
            return false;
        }
        int repetida = posicionDe(lista, getClave(newEntity));
        if (repetida != -1 && repetida != posicion) {
            return false;
        }
        lista.set(posicion, newEntity);
        return gestor.escribirTodo(lista);
    }
    // deleteData()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public boolean deleteData(T entity) {
        if (entity == null) {
            return false;
        }
        ArrayList<T> lista = getDataList();
        int posicion = posicionDe(lista, getClave(entity));
        if (posicion == -1) {
            return false;
        }
        lista.remove(posicion);
        return gestor.escribirTodo(lista);
    }

    // ══════════════════════════════════════════════════════════════
    //  APOYO INTERNO
    // ══════════════════════════════════════════════════════════════
    // posicionDe()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    private int posicionDe(List<T> lista, String clave) {
        for (int i = 0; i < lista.size(); i++) {
            if (getClave(lista.get(i)).equalsIgnoreCase(clave)) {
                return i;
            }
        }
        return -1;
    }
}
