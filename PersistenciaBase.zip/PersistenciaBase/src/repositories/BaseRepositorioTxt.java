// PAQUETE REPOSITORIES //
package repositories;

import interfaces.IRepositorio;
import persistence.GestorArchivoTxt;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

// ══════════════════════════════════════════════════════════════
//  CLASE  ·  BaseRepositorioTxt<T>
// ══════════════════════════════════════════════════════════════
//  Repositorio genérico para archivos de texto. Implementa todo el CRUD; cada subclase solo dice cómo convertir su objeto a una línea y viceversa.
//  * ABSTRACCIÓN *
//    - Es abstracta: no se instancia, solo es la plantilla de los repositorios TXT
//  * HERENCIA *
//    - Cada repositorio concreto hereda el CRUD completo y solo define toLinea, fromLinea y getClave
//  * GENERICIDAD *
//    - El parámetro <T> la hace reutilizable para cualquier modelo
//  * COMPOSICIÓN *
//    - Tiene un GestorArchivoTxt y le delega la lectura y escritura del archivo
// ══════════════════════════════════════════════════════════════
public abstract class BaseRepositorioTxt<T> implements IRepositorio<T> {

    // ─────────────────── ATRIBUTOS ───────────────────
    protected GestorArchivoTxt gestor;
    protected String delimitador;
    // ───────────────── CONSTRUCTORES ─────────────────
    public BaseRepositorioTxt(String nombreArchivo, String delimitador) {
        this.gestor = new GestorArchivoTxt(nombreArchivo);
        this.delimitador = delimitador;
    }

    // ══════════════════════════════════════════════════════════════
    //  MÉTODOS QUE DEFINE CADA SUBCLASE
    // ══════════════════════════════════════════════════════════════
    // getClave()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    protected abstract String getClave(T entity);
    // toLinea()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    protected abstract String toLinea(T entity);
    // fromLinea()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    protected abstract T fromLinea(String linea);

    // ══════════════════════════════════════════════════════════════
    //  LECTURA
    // ══════════════════════════════════════════════════════════════
    // getDataList()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public ArrayList<T> getDataList() {
        ArrayList<T> lista = new ArrayList<>();
        for (String linea : gestor.leerLineas()) {
            T entidad = fromLinea(linea);
            if (entidad != null) {
                lista.add(entidad);
            }
        }
        return lista;
    }
    // buscarPorClave()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public T buscarPorClave(String clave) {
        for (T entidad : getDataList()) {
            if (getClave(entidad).equalsIgnoreCase(clave)) {
                return entidad;
            }
        }
        return null;
    }

    // ══════════════════════════════════════════════════════════════
    //  ESCRITURA
    // ══════════════════════════════════════════════════════════════
    // insertData()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public boolean insertData(T entity) {
        if (entity == null || buscarPorClave(getClave(entity)) != null) {
            return false;
        }
        ArrayList<T> lista = getDataList();
        lista.add(entity);
        return guardarTodo(lista);
    }
    // updateData()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public boolean updateData(T oldEntity, T newEntity) {
        if (oldEntity == null || newEntity == null) {
            return false;
        }
        ArrayList<T> lista = getDataList();
        int posicion = posicionDe(lista, getClave(oldEntity));
        if (posicion == -1) {
            return false;
        }
        int repetida = posicionDe(lista, getClave(newEntity));
        if (repetida != -1 && repetida != posicion) {
            return false;
        }
        lista.set(posicion, newEntity);
        return guardarTodo(lista);
    }
    // deleteData()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override public boolean deleteData(T entity) {
        if (entity == null) {
            return false;
        }
        ArrayList<T> lista = getDataList();
        int posicion = posicionDe(lista, getClave(entity));
        if (posicion == -1) {
            return false;
        }
        lista.remove(posicion);
        return guardarTodo(lista);
    }

    // ══════════════════════════════════════════════════════════════
    //  APOYO INTERNO
    // ══════════════════════════════════════════════════════════════
    // dividir()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    protected String[] dividir(String linea) {
        return linea.split(Pattern.quote(delimitador), -1);
    }
    // posicionDe()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    private int posicionDe(List<T> lista, String clave) {
        for (int i = 0; i < lista.size(); i++) {
            if (getClave(lista.get(i)).equalsIgnoreCase(clave)) {
                return i;
            }
        }
        return -1;
    }
    // guardarTodo()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    private boolean guardarTodo(List<T> lista) {
        List<String> lineas = new ArrayList<>();
        for (T entidad : lista) {
            lineas.add(toLinea(entidad));
        }
        return gestor.escribirLineas(lineas);
    }
}
