// PAQUETE REPOSITORIES //
package repositories;

import models.Institucion;

// ══════════════════════════════════════════════════════════════
//  CLASE  ·  InstitucionRepositorioJson
// ══════════════════════════════════════════════════════════════
//  Ejemplo de repositorio JSON: guarda las instituciones en instituciones.json.
//  * HERENCIA *
//    - Hereda el CRUD completo de BaseRepositorioJson y solo define la clave de una Institucion
//  * POLIMORFISMO *
//    - Sobrescribe getClave con el comportamiento propio de Institucion
// ══════════════════════════════════════════════════════════════
public class InstitucionRepositorioJson extends BaseRepositorioJson<Institucion> {

    // ───────────────── CONSTRUCTORES ─────────────────
    public InstitucionRepositorioJson() {
        super("instituciones.json", Institucion.class);
    }

    // ══════════════════════════════════════════════════════════════
    //  CONVERSIÓN
    // ══════════════════════════════════════════════════════════════
    // getClave()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override protected String getClave(Institucion entity) {
        return entity.getNombre();
    }
}
