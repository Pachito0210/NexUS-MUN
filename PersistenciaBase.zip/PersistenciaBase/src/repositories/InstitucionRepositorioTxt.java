// PAQUETE REPOSITORIES //
package repositories;

import models.Institucion;

// ══════════════════════════════════════════════════════════════
//  CLASE  ·  InstitucionRepositorioTxt
// ══════════════════════════════════════════════════════════════
//  Ejemplo de repositorio TXT: guarda las instituciones en instituciones.txt, una por línea (nombre|tipo).
//  * HERENCIA *
//    - Hereda el CRUD completo de BaseRepositorioTxt y solo define cómo convertir una Institucion a línea
//  * POLIMORFISMO *
//    - Sobrescribe getClave, toLinea y fromLinea con el comportamiento propio de Institucion
// ══════════════════════════════════════════════════════════════
public class InstitucionRepositorioTxt extends BaseRepositorioTxt<Institucion> {

    // ───────────────── CONSTRUCTORES ─────────────────
    public InstitucionRepositorioTxt() {
        super("instituciones.txt", "|");
    }

    // ══════════════════════════════════════════════════════════════
    //  CONVERSIÓN
    // ══════════════════════════════════════════════════════════════
    // getClave()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override protected String getClave(Institucion entity) {
        return entity.getNombre();
    }
    // toLinea()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override protected String toLinea(Institucion entity) {
        return entity.getNombre() + delimitador + entity.getTipo();
    }
    // fromLinea()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    @Override protected Institucion fromLinea(String linea) {
        String[] campos = dividir(linea);
        if (campos.length < 2) {
            return null;
        }
        Institucion institucion = new Institucion();
        institucion.setNombre(campos[0]);
        institucion.setTipo(campos[1]);
        return institucion;
    }
}
