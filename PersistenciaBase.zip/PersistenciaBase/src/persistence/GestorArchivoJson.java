// PAQUETE PERSISTENCE //
package persistence;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

// ══════════════════════════════════════════════════════════════
//  CLASE  ·  GestorArchivoJson<T>
// ══════════════════════════════════════════════════════════════
//  Lee y escribe una lista de objetos T en un archivo JSON de la carpeta src/files usando Gson.
//  * GENERICIDAD *
//    - Con el parámetro <T> y la clase recibida, el mismo gestor sirve para cualquier modelo
//  * ENCAPSULAMIENTO *
//    - Nadie fuera de esta clase sabe cómo se arma la ruta ni cómo se configura Gson
//  * SEPARACIÓN DE RESPONSABILIDADES *
//    - Este gestor maneja el archivo; las reglas de agregar, editar y borrar le tocan al repositorio
// ══════════════════════════════════════════════════════════════
public class GestorArchivoJson<T> {

    // ─────────────────── ATRIBUTOS ───────────────────
    private static final String CARPETA = "src/files/";
    private String nombreArchivo;
    private Class<T> clase;
    private Gson gson;
    // ───────────────── CONSTRUCTORES ─────────────────
    public GestorArchivoJson(String nombreArchivo, Class<T> clase) {
        this(nombreArchivo, clase, new GsonBuilder()
                .setPrettyPrinting()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ss")
                .create());
    }
    public GestorArchivoJson(String nombreArchivo, Class<T> clase, Gson gson) {
        this.nombreArchivo = nombreArchivo;
        this.clase = clase;
        this.gson = gson;
    }

    // ─────────────── GETTERS & SETTERS ───────────────
    public String getNombreArchivo() { return nombreArchivo; }

    // ══════════════════════════════════════════════════════════════
    //  ARCHIVO
    // ══════════════════════════════════════════════════════════════
    // getRuta()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    private Path getRuta() {
        return Paths.get(CARPETA + nombreArchivo);
    }
    // getTipoLista()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    private Type getTipoLista() {
        return TypeToken.getParameterized(ArrayList.class, clase).getType();
    }

    // ══════════════════════════════════════════════════════════════
    //  LECTURA Y ESCRITURA
    // ══════════════════════════════════════════════════════════════
    // leerTodo()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    public ArrayList<T> leerTodo() {
        Path ruta = getRuta();
        if (!Files.exists(ruta)) {
            return new ArrayList<>();
        }
        try (Reader lector = Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
            ArrayList<T> datos = gson.fromJson(lector, getTipoLista());
            return (datos == null) ? new ArrayList<>() : datos;
        } catch (IOException | JsonParseException e) {
            System.out.println("No se pudo leer " + nombreArchivo + ": " + e.getMessage());
            return new ArrayList<>();
        }
    }
    // escribirTodo()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    public boolean escribirTodo(List<T> datos) {
        try {
            Path ruta = getRuta();
            Files.createDirectories(ruta.toAbsolutePath().getParent());
            try (Writer escritor = Files.newBufferedWriter(ruta, StandardCharsets.UTF_8)) {
                gson.toJson(datos, getTipoLista(), escritor);
            }
            return true;
        } catch (IOException | JsonParseException e) {
            System.out.println("No se pudo escribir " + nombreArchivo + ": " + e.getMessage());
            return false;
        }
    }
}
