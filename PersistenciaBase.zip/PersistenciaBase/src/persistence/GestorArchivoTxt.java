// PAQUETE PERSISTENCE //
package persistence;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

// ══════════════════════════════════════════════════════════════
//  CLASE  ·  GestorArchivoTxt
// ══════════════════════════════════════════════════════════════
//  Lee y escribe líneas de texto en un archivo de la carpeta src/files. No sabe nada de modelos, solo de líneas.
//  * ENCAPSULAMIENTO *
//    - Nadie fuera de esta clase sabe cómo se arma la ruta ni cómo se abre el archivo
//  * SEPARACIÓN DE RESPONSABILIDADES *
//    - Este gestor maneja el archivo; convertir objetos a líneas le toca al repositorio
// ══════════════════════════════════════════════════════════════
public class GestorArchivoTxt {

    // ─────────────────── ATRIBUTOS ───────────────────
    private static final String CARPETA = "src/files/";
    private String nombreArchivo;
    // ───────────────── CONSTRUCTORES ─────────────────
    public GestorArchivoTxt(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    // ─────────────── GETTERS & SETTERS ───────────────
    public String getNombreArchivo() { return nombreArchivo; }

    // ══════════════════════════════════════════════════════════════
    //  ARCHIVO
    // ══════════════════════════════════════════════════════════════
    // getRuta()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    private Path getRuta() {
        return Paths.get(CARPETA + nombreArchivo);
    }

    // ══════════════════════════════════════════════════════════════
    //  LECTURA Y ESCRITURA
    // ══════════════════════════════════════════════════════════════
    // leerLineas()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    public ArrayList<String> leerLineas() {
        ArrayList<String> lineas = new ArrayList<>();
        Path ruta = getRuta();
        if (!Files.exists(ruta)) {
            return lineas;
        }
        try {
            for (String linea : Files.readAllLines(ruta, StandardCharsets.UTF_8)) {
                if (!linea.trim().isEmpty()) {
                    lineas.add(linea);
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo leer " + nombreArchivo + ": " + e.getMessage());
        }
        return lineas;
    }
    // escribirLineas()
    //  - COMO FUNCIONA: ...
    //  - PARA QUÉ SIRVE: ...
    //  * CONCEPTO DE POO *
    //    - ...
    public boolean escribirLineas(List<String> lineas) {
        try {
            Path ruta = getRuta();
            Files.createDirectories(ruta.toAbsolutePath().getParent());
            Files.write(ruta, lineas, StandardCharsets.UTF_8);
            return true;
        } catch (IOException e) {
            System.out.println("No se pudo escribir " + nombreArchivo + ": " + e.getMessage());
            return false;
        }
    }
}
